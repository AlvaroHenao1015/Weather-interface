//
//  SwiftUI_WeatherApp.swift
//  SwiftUI-Weather
//
//  Created by Alvaro Henao on 21/11/23.
//

import SwiftUI

@main
struct SwiftUI_WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}





